import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {UploadExcelDataComponent} from './upload-excel-data.component';

describe('UploadExcelDataComponent', () => {
  let component: UploadExcelDataComponent;
  let fixture: ComponentFixture<UploadExcelDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UploadExcelDataComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadExcelDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
