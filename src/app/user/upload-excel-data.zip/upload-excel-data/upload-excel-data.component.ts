import {Component, OnInit} from '@angular/core';
import {UploadExcelDataService} from './upload-excel-data.service';
import {AuthService} from '../../shared/auth.service';
import {Router} from '@angular/router';
import {SessionService} from '../../shared/session.service';
import {AppConstants} from '../../shared/app.constants';
import * as XLSX from 'xlsx';
import {FileUploader, FileSelectDirective} from 'ng2-file-upload/ng2-file-upload';

declare var $: any;
const URL = AppConstants.apiBaseUrlUser + 'upload_file2';

@Component({
  selector: 'app-upload-excel-data',
  templateUrl: './upload-excel-data.component.html',
  styleUrls: ['./upload-excel-data.component.css']
})
export class UploadExcelDataComponent implements OnInit {
  loader = false;
  errorMsg = '';

  constructor(private service: UploadExcelDataService,
              private router: Router,
              private authService: AuthService,
              private sessionService: SessionService) {

  }

  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});

  assetsPath: any;
  excel_file_type: any;
  dropdown = [
    {id: 2, value: 'company_upload'},
    {id: 3, value: 'regular_upload'},
    {id: 1, value: 'excel_data_combine'}
  ];

  ngOnInit() {
    this.assetsPath = AppConstants.assetsPath;
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('excel_file_type', this.excel_file_type);
    };
    this.uploader.onAfterAddingFile = (file) => {
      file.withCredentials = false;
      this.errorMsg = '';
    };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      // console.log('ImageUpload:uploaded:', item, status, response);
      this.loader = false;
      response = JSON.parse(response);
      // if (response.msg === 'success') {
      //   this.errorMsg = 'Uploaded successfully. Please wait for the email response!';
      // }
      if (response.msg === 'failed') {
        this.errorMsg = 'There is something gone wrong, Please contact to Administrator';
      } else if (response.msg === 'invalid_file') {
        this.errorMsg = 'Invalid File';
      } else if (response.msg === 'select_type') {
        this.errorMsg = 'Please select the excel type';
      } else {
        this.errorMsg = 'Uploaded successfully. Please wait for the email response!';
      }
    };
  }
}
