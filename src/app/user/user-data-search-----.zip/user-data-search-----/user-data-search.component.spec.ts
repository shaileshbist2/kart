import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {UserDataSearchComponent} from './user-data-search.component';

describe('UserDataSearchComponent', () => {
  let component: UserDataSearchComponent;
  let fixture: ComponentFixture<UserDataSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UserDataSearchComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDataSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
