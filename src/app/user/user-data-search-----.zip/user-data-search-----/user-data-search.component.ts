import {Component, OnInit, ViewChild, AfterViewInit} from '@angular/core';
import {UserDataSearchService} from './user-data-search.service';
import {Router} from '@angular/router';
import {UserContactModel} from '../../models/user/userDataSearchModel';
import {Subject} from 'rxjs';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {AuthService} from '../../shared/auth.service';
import {DataTableDirective} from 'angular-datatables';

declare var $: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-user-data-search',
  styleUrls: ['./user-data-search.component.css'],
  templateUrl: './user-data-search.component.html'
})
export class UserDataSearchComponent implements OnInit, AfterViewInit {
  inputType2 = new Subject<string>();
  dtOptions: any = {};
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtTrigger: Subject<any> = new Subject();
  totalRec: any;
  persons: any;
  input_value: any;
  contactModel: any;
  companyModel: any;
  searchInput = '';
  isAuthorized: any;
  loading = false;
  showCompanyDetail = false;
  purchaseBtn = true;
  zeroCreditFlag = false;
  creditsDetails: any;
  filterObject = {
    country: [],
    state: [],
    industry: [],
    domain: [],
    management_level: [],
    revenue: []
  };
  searchCountryFilter: any;
  searchStateFilter: any;
  searchIndustryFilter: any;
  searchDomainFilter: any;
  searchManagementLevelFilter: any;
  searchRevenueFilter: any;

  country: any = [];
  state: any = [];
  domain: any = [];
  industry: any = [];
  department: any = [];
  selectedCountry = [];
  selectedState = [];
  selectedDomain = [];
  selectedIndustry = [];
  selectedDepartment = [];
  country_setting = {};
  state_setting = {};
  domain_setting = {};
  industry_setting = {};
  department_setting = {};
  superObj: any;
  allpersons = false;

  filterCheckedObj: any;
  filterObject_api: any;
  checkedObj = {
    country: [],
    state: [],
    industry: [],
    domain: [],
    management_level: [],
    revenue: []
  };
  countryArray = [];
  stateArray = [];
  industryArray = [];
  domainArray = [];
  managementLevelArray = [];
  revenueArray = [];
  selectAllCountry = false;
  selectAllState = false;
  selectAllIndustry = false;
  selectAllDomain = false;
  selectAllManagementLevel = false;
  selectAllRevenue = false;
  getItView = false;
  spinner = false;
  errorMsgView = false;
  successMsg = '';
  searchingBy = 'default';

  constructor(private service: UserDataSearchService,
              private router: Router,
              private authService: AuthService,
              private http: HttpClient) {
    this.inputType2.pipe(
      debounceTime(700),
      distinctUntilChanged())
      .subscribe(value => {
        this.dataTableList_user(value);
      });
  }

  dataTableList_user(input_value) {
    // const checked_obj = this.checkedObj;
    this.input_value = input_value;
    this.dtOptions = {
      pagingType: 'full_numbers',
      processing: true,
      serverSide: true,
      deferRender: true,
      destroy: true,
      searching: false,
      lengthChange: true,
      pageLength: 10,
      dom: `<'top'<'actions'>lfpi<'clear'>><'clear'>rt<'bottom'>
            <'top'li><'bottom'><'clear'>
            <'row'<'col-sm-12'p>>`,
      language: {
        search: 'Filter records:',
        zeroRecords: '',
        processing: `<div class='a' style='--n: 5;'>
                        <div class='dot' style='--i: 0;'></div>
                        <div class='dot' style='--i: 1;'></div>
                        <div class='dot' style='--i: 2;'></div>
                        <div class='dot' style='--i: 3;'></div>
                        <div class='dot' style='--i: 4;'></div>
                      </div>`
      },
      ordering: false,
      ajax: (dataTablesParameters: any, callback) => {
        this.loading = true;
        this.service.dataTableList_user(dataTablesParameters, this.input_value, this.checkedObj, this.searchingBy).subscribe(resp => {
          this.persons = resp.data;
          this.totalRec = resp.recordsTotal;
          callback({
            recordsTotal: resp.recordsTotal,
            recordsFiltered: resp.recordsFiltered,
            data: []
          });
          this.loading = false;
        });
      },
      /*columns: [{title: 'NAME'},
        {title: 'COMPANY'},
        {title: 'DESIGNATION'},
        {title: 'STATE'},
        {title: 'COUNTRY'},
        {title: 'UPDATED'},
        {title: 'VIEW'}],*/
      responsive: true,
      // scrollY: 420,
      // scrollX: 450
    };
    this.dtTrigger.next();
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  resetSearch() {
    this.totalRec = '';
    this.dtOptions = {};
    this.persons = '';
    this.input_value = '';
    this.contactModel = '';
    this.companyModel = '';
    this.searchInput = '';
    this.isAuthorized = '';
    this.loading = false;
    this.filterObject = {
      country: [],
      state: [],
      industry: [],
      domain: [],
      management_level: [],
      revenue: []
    };
    this.searchCountryFilter = '';
    this.searchStateFilter = '';
    this.searchIndustryFilter = '';
    this.searchDomainFilter = '';
    this.searchManagementLevelFilter = '';

    this.country = [];
    this.state = [];
    this.domain = [];
    this.industry = [];
    this.department = [];
    this.selectedCountry = [];
    this.selectedState = [];
    this.selectedDomain = [];
    this.selectedIndustry = [];
    this.selectedDepartment = [];
    this.country_setting = {};
    this.state_setting = {};
    this.domain_setting = {};
    this.industry_setting = {};
    this.department_setting = {};
    this.superObj = '';

    this.filterCheckedObj = '';
    this.filterObject_api = '';
    this.checkedObj = {
      country: [],
      state: [],
      industry: [],
      domain: [],
      management_level: [],
      revenue: []
    };
    this.countryArray = [];
    this.stateArray = [];
    this.industryArray = [];
    this.domainArray = [];
    this.managementLevelArray = [];
    this.selectAllCountry = false;
    this.selectAllState = false;
    this.selectAllIndustry = false;
    this.selectAllDomain = false;
    this.selectAllManagementLevel = false;
    this.getItView = false;
    this.spinner = false;
    this.errorMsgView = false;
    this.successMsg = '';
    this.searchingBy = 'default';
    this.allpersons = false;
    this.countrySetting();
    this.stateSetting();
    this.domainSetting();
    this.industrySetting();
    this.departmentSetting();
    this.contactModel = new UserContactModel();
    this.getAllSubjectData_user(this.checkedObj);
  }

  countrySetting() {
    this.country_setting = {
      text: 'Select Countries',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      primaryKey: 'id',
      labelKey: 'country_name',
      enableSearchFilter: true,
      searchBy: ['country_name']
    };
  }

  stateSetting() {
    this.state_setting = {
      text: 'Select States',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      primaryKey: 'id',
      labelKey: 'state_name',
      enableSearchFilter: true,
      searchBy: ['state_name']
    };
  }

  domainSetting() {
    this.domain_setting = {
      text: 'Select Domains',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      primaryKey: 'id',
      labelKey: 'domain_name',
      enableSearchFilter: true,
      searchBy: ['domain_name']
    };
  }

  industrySetting() {
    this.industry_setting = {
      text: 'Select Industries',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      primaryKey: 'id',
      labelKey: 'industry_name',
      enableSearchFilter: true,
      searchBy: ['industry_name']
    };
  }

  departmentSetting() {
    this.department_setting = {
      text: 'Select Departments',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      primaryKey: 'id',
      labelKey: 'department_name',
      enableSearchFilter: true,
      searchBy: ['department_name']
    };
  }

  /********************** Checkbox Selection on DataTable *****************************/
  checkAllSelectCheckbox(isChecked) {
    const data_set = this.persons.filter(function (data) {
      return data.selected === true;
    });
    if (data_set.length > 0) {
      this.getItView = true;
    } else {
      this.getItView = false;
    }
  }

  toggleSelect = function (event) {
    this.allpersons = event.target.checked;
    this.persons.forEach(function (item) {
      item.selected = event.target.checked;
    });
    this.getItView = this.allpersons;
  };

  purchaseSelectedContacts(isValid: boolean) {
    const data_set = this.persons.filter(function (data) {
      return data.selected === true;
    });
    if (!isValid) {
      return;
    }
    if (data_set.length > 0) {
      this.spinner = true;
      this.service.purchaseSelectedContacts_user(data_set).subscribe(response => {
        this.spinner = false;
        this.errorMsgView = false;
        this.successMsg = 'Successfully done';
        this.dataTableList_user('');
        this.getCreditsStatus_user();
        this.allpersons = false;
      }, error => {
        this.successMsg = '';
        this.spinner = false;
        this.errorMsgView = true;
      });
    }
  }

  /***********************************************************************************/

  selectAllCheckboxToUncheck(check) {
    if (check === 'country') {
      if (this.countryArray.length === 0) {
        this.selectAllCountry = false;
      }
    } else if (check === 'state') {
      if (this.stateArray.length === 0) {
        this.selectAllState = false;
      }
    } else if (check === 'industry') {
      if (this.industryArray.length === 0) {
        this.selectAllIndustry = false;
      }
    } else if (check === 'domain') {
      if (this.domainArray.length === 0) {
        this.selectAllDomain = false;
      }
    } else if (check === 'management_level') {
      if (this.managementLevelArray.length === 0) {
        this.selectAllManagementLevel = false;
      }
    } else if (check === 'revenue') {
      if (this.revenueArray.length === 0) {
        this.selectAllRevenue = false;
      }
    }
  }

  selectAllCheckbox(check, isChecked) {
    this.searchInput = null;
    if (check === 'country') {
      this.countryArray = [];
      this.filterObject.country.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.countryArray.push(elem);
        } else if (isChecked === false) {
          this.countryArray.splice(this.countryArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    } else if (check === 'state') {
      this.stateArray = [];
      this.filterObject.state.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.stateArray.push(elem);
        } else if (isChecked === false) {
          this.stateArray.splice(this.stateArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    } else if (check === 'industry') {
      this.industryArray = [];
      this.filterObject.industry.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.industryArray.push(elem);
        } else if (isChecked === false) {
          this.industryArray.splice(this.industryArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    } else if (check === 'domain') {
      this.domainArray = [];
      this.filterObject.domain.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.domainArray.push(elem);
        } else if (isChecked === false) {
          this.domainArray.splice(this.domainArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    } else if (check === 'management_level') {
      this.revenueArray = [];
      this.filterObject.management_level.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.revenueArray.push(elem);
        } else if (isChecked === false) {
          this.revenueArray.splice(this.revenueArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    } else if (check === 'revenue') {
      this.managementLevelArray = [];
      this.filterObject.revenue.map((elem) => {
        elem['is_checked'] = isChecked;
        if (isChecked === true) {
          this.revenueArray.push(elem);
        } else if (isChecked === false) {
          this.revenueArray.splice(this.revenueArray.map((item) => item.id).indexOf(elem.id), 1);
        }
      });
    }
    this.checkedObj = {
      country: this.countryArray,
      state: this.stateArray,
      industry: this.industryArray,
      domain: this.domainArray,
      management_level: this.managementLevelArray,
      revenue: this.revenueArray
    };
    this.getAllSubjectData_user(this.checkedObj);
  }

  pushCheckedObj(check, obj, isChecked) {
    this.searchInput = null;
    if (check === 'country') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.countryArray.push(obj);
      } else if (isChecked === false) {
        this.countryArray.splice(this.countryArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    } else if (check === 'state') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.stateArray.push(obj);
      } else if (isChecked === false) {
        this.stateArray.splice(this.stateArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    } else if (check === 'industry') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.industryArray.push(obj);
      } else if (isChecked === false) {
        this.industryArray.splice(this.industryArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    } else if (check === 'domain') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.domainArray.push(obj);
      } else if (isChecked === false) {
        this.domainArray.splice(this.domainArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    } else if (check === 'management_level') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.managementLevelArray.push(obj);
      } else if (isChecked === false) {
        this.managementLevelArray.splice(this.managementLevelArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    } else if (check === 'revenue') {
      obj['is_checked'] = isChecked;
      if (isChecked === true) {
        this.revenueArray.push(obj);
      } else if (isChecked === false) {
        this.revenueArray.splice(this.revenueArray.map((item) => item.id).indexOf(obj.id), 1);
      }
    }
    setTimeout(() => {
      this.checkedObj = {
        country: this.countryArray,
        state: this.stateArray,
        industry: this.industryArray,
        domain: this.domainArray,
        management_level: this.managementLevelArray,
        revenue: this.revenueArray
      };
      this.getAllSubjectData_user(this.checkedObj);
    }, 500);
  }

  searchingByFunc(val) {
    this.searchingBy = val;
    this.getAllSubjectData_user(this.checkedObj);
  }

  getAllSubjectData_user(checked_obj) {
    this.service.getAllSubjectData_user(checked_obj, this.searchingBy).subscribe(response => {
      this.filterObject_api = response.data[0];
      for (const d1 of this.checkedObj.country) {
        for (const d2 in this.filterObject_api.country) {
          if (this.filterObject_api.country[d2].country_name === d1.country_name) {
            this.filterObject_api.country[d2].is_checked = true;
          }
        }
      }
      for (const d1 of this.checkedObj.state) {
        for (const d2 in this.filterObject_api.state) {
          if (this.filterObject_api.state[d2].state_name === d1.state_name) {
            this.filterObject_api.state[d2].is_checked = true;
          }
        }
      }
      for (const d1 of this.checkedObj.industry) {
        for (const d2 in this.filterObject_api.industry) {
          if (this.filterObject_api.industry[d2].industry_name === d1.industry_name) {
            this.filterObject_api.industry[d2].is_checked = true;
          }
        }
      }
      for (const d1 of this.checkedObj.domain) {
        for (const d2 in this.filterObject_api.domain) {
          if (this.filterObject_api.domain[d2].domain_name === d1.domain_name) {
            this.filterObject_api.domain[d2].is_checked = true;
          }
        }
      }
      for (const d1 of this.checkedObj.management_level) {
        for (const d2 in this.filterObject_api.management_level) {
          if (this.filterObject_api.management_level[d2].management_level === d1.management_level) {
            this.filterObject_api.management_level[d2].is_checked = true;
          }
        }
      }
      for (const d1 of this.checkedObj.revenue) {
        for (const d2 in this.filterObject_api.revenue) {
          if (this.filterObject_api.revenue[d2].revenue === d1.revenue) {
            this.filterObject_api.revenue[d2].is_checked = true;
          }
        }
      }
      this.filterObject = this.filterObject_api;
    });
    this.dataTableList_user('');
  }

  /********** CHECK CONTACT PURCHASED OR NOT *******************/
  isContactPurchased_user(peopleDataId) {
    this.loading = true;
    this.service.isContactPurchased_user(peopleDataId).subscribe(response => {
      this.contactModel = response.data[0].personDetail[0];
      this.companyModel = response.data[0].companyDetail[0];
      this.showCompanyDetail = this.companyModel !== undefined; // true or false
      this.loading = false;
    });
  }

  /************ GET CREDITS STATUS *******************************************/
  getCreditsStatus_user() {
    this.service.getCreditsStatus_user().subscribe(response => {
      this.creditsDetails = response.data[0].creditsDetails[0];
    });
  }

  /********** PURCHASE NOW **************************************/
  purchaseContactNow_user(people_data_id) {
    this.service.purchaseContactNow_user(people_data_id).subscribe(response => {
      this.isContactPurchased_user(people_data_id);
      this.getCreditsStatus_user();
      this.zeroCreditFlag = false;
    }, error => {
      if (error === 'zero_credit_found') {
        this.zeroCreditFlag = true;
        this.purchaseBtn = false;
      } else {
        this.zeroCreditFlag = false;
        this.purchaseBtn = true;
      }
    });
  }

  getContactObjInfo(data) {
    this.contactModel = data;
  }

  checkDataId(person) {
    this.isContactPurchased_user(person.people_data_id);
  }

  checkAuth() {
    this.isAuthorized = this.authService.isAuthorised();
    if (this.isAuthorized === false) {
      this.router.navigateByUrl('user/login');
    }
  }

  ngOnInit() {
    this.countrySetting();
    this.stateSetting();
    this.domainSetting();
    this.industrySetting();
    this.departmentSetting();
    this.contactModel = new UserContactModel();
    this.getAllSubjectData_user(this.checkedObj);
  }

  onCountrySelect($event) {
  }

  onStateSelect($event) {
  }

  onDomainSelect($event) {
  }

  onIndustrySelect($event) {
  }

  onDepartmentSelect($event) {
  }

  OnCountryDeSelect(item: any) {
  }

  OnStateDeSelect(item: any) {
  }

  OnDomainDeSelect(item: any) {
  }

  OnIndustryDeSelect(item: any) {
  }

  OnDepartmentDeSelect(item: any) {
  }

  onSelectAllCountry(items: any) {
  }

  onSelectAllState(items: any) {
  }

  onSelectAllDomain(items: any) {
  }

  onSelectAllIndustry(items: any) {
  }

  onSelectAllDepartment(items: any) {
  }

  onDeSelectAllCountry(items: any) {
  }

  onDeSelectAllState(items: any) {
  }

  onDeSelectAllDomain(items: any) {
  }

  onDeSelectAllIndustry(items: any) {
  }

  onDeSelectAllDepartment(items: any) {
  }

  optionsObject(evt, check, selectedObj) {
    return this.superObj = {
      evt: evt,
      check: check,
      selected_obj: selectedObj
    };
  }

  onSearchCountry(evt: any) {
    this.superObj = this.optionsObject(evt, 'country', []);
    this.service.setFilterData_user(this.superObj).subscribe(response => {
      this.country = response.data[0].country;
    });
  }

  onSearchState(evt: any) {
    this.superObj = this.optionsObject(evt, 'state', this.selectedCountry);
    this.service.setFilterData_user(this.superObj).subscribe(response => {
      this.state = response.data[0].state;
    });
  }

  onSearchDomain(evt: any) {
    this.superObj = this.optionsObject(evt, 'domain', []);
    this.service.setFilterData_user(this.superObj).subscribe(response => {
      this.domain = response.data[0].domain;
    });
  }

  onSearchIndustry(evt: any) {
    this.superObj = this.optionsObject(evt, 'industry', []);
    this.service.setFilterData_user(this.superObj).subscribe(response => {
      this.industry = response.data[0].industry;
    });
  }

  onSearchDepartment(evt: any) {
    this.superObj = this.optionsObject(evt, 'department', []);
    this.service.setFilterData_user(this.superObj).subscribe(response => {
      this.department = response.data[0].department;
    });
  }
}
