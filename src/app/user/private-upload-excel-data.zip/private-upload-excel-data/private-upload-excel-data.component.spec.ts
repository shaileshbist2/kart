import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {PrivateUploadExcelDataComponent} from './private-upload-excel-data.component';

describe('PrivateUploadExcelDataComponent', () => {
  let component: PrivateUploadExcelDataComponent;
  let fixture: ComponentFixture<PrivateUploadExcelDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PrivateUploadExcelDataComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateUploadExcelDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
