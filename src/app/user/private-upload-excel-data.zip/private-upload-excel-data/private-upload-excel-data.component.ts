import {Component, OnInit} from '@angular/core';
import {PrivateUploadExcelDataService} from './private-upload-excel-data.service';
import {AuthService} from '../../shared/auth.service';
import {Router} from '@angular/router';
import {SessionService} from '../../shared/session.service';
import {AppConstants} from "../../shared/app.constants";
import * as XLSX from 'xlsx';
import {FileUploader, FileSelectDirective} from 'ng2-file-upload/ng2-file-upload';

declare var $: any;
const URL = AppConstants.apiBaseUrlUser + 'upload_file';

@Component({
  selector: 'app-private-upload-excel-data',
  templateUrl: './private-upload-excel-data.component.html',
  styleUrls: ['./private-upload-excel-data.component.css']
})
export class PrivateUploadExcelDataComponent implements OnInit {
  loader = false;

  constructor(private service: PrivateUploadExcelDataService,
              private router: Router,
              private authService: AuthService,
              private sessionService: SessionService) {

  }

  // fileToUpload: File = null;
  // handleFileInput(files: FileList) {
  //   this.fileToUpload = files.item(0);
  // }
  //
  // uploadFileToActivity() {
  //   this.service.postFile(this.fileToUpload).subscribe(data => {
  //     console.log(data);
  //     // do something, if upload success
  //   }, error => {
  //     console.log(error);
  //   });
  // }

  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});

  assetsPath: any;
  errorMsg = '';

  ngOnInit() {
    this.assetsPath = AppConstants.assetsPath;

    this.uploader.onAfterAddingFile = (file) => {
      file.withCredentials = false;
      this.errorMsg = '';
    };
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      // console.log('ImageUpload:uploaded:', item, status, response);
      this.loader = false;
      response = JSON.parse(response);
      if (response.msg == 'success') {
        this.errorMsg = 'Uploaded successfully!';
      } else if (response.msg == 'invalid_file') {
        this.errorMsg = 'Invalid File';
      } else {
        this.errorMsg = 'Please please check your internet connection or contact to the administrator!';
      }
    };
  }

}
