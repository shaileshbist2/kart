import {Injectable} from '@angular/core';
import {ApiService} from '../../shared/api.service';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {HelperService} from '../../shared/helper.service';

@Injectable()
export class PrivateUploadExcelDataService {
  constructor(private apiService: ApiService,
              private httpClient: HttpClient,
              private helperService: HelperService) {
  }

  // postFile(fileToUpload: File): Observable<boolean> {
  //   const requestParam = {};
  //   const endpoint = './user/upload_file';
  //   const formData: FormData = new FormData();
  //   formData.append('img', fileToUpload, fileToUpload.name);
  //   return this.httpClient.post(endpoint, formData, requestParam)
  //     .map(() => {
  //       return true;
  //     })
  //     .catch(this.helperService.handleError);
  // }


}
