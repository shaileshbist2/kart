import {NgModule} from '@angular/core';
import {DriverHeaderComponent} from "../../modules/driver/driver-header/driver-header.component";
import {SharedModule} from "./shared.module";


@NgModule({
    imports: [
        SharedModule
    ],
    declarations: [DriverHeaderComponent],
    exports: [DriverHeaderComponent, SharedModule]
})
export class DriverSharedModule {

}
