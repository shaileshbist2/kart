import {NgModule} from '@angular/core';
import {CompanyHeaderComponent} from "../../modules/company/company-header/company-header.component";
import {SharedModule} from "./shared.module";

@NgModule({
    imports: [
        SharedModule
    ],
    declarations: [CompanyHeaderComponent],
    exports: [CompanyHeaderComponent, SharedModule]
})
export class CompanySharedModule {
}
