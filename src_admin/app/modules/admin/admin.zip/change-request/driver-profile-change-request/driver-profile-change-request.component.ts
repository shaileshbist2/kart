import {Component, OnInit} from '@angular/core';
import {ChangeRequestService} from "../change-request.service";
import {Subject} from "rxjs/Subject";
import Swal from 'sweetalert2';

@Component({
    selector: 'app-driver-profile-change-request',
    templateUrl: './driver-profile-change-request.component.html',
    styleUrls: ['./driver-profile-change-request.component.css']
})
export class DriverProfileChangeRequestComponent implements OnInit {

    public requests: any = [];
    public loading: boolean = false;
    public dtOptions: DataTables.Settings = {};
    public dtTrigger: Subject<any> = new Subject();
    public display = 'none';
    public requestStatus: any = [];
    public requestType = 1201;

    constructor(private service: ChangeRequestService) {
    }

    getDriverRequests() {
        this.loading = true;
        this.service.getDriverProfileRequest(this.requestType).subscribe(response => {
            this.loading = false;
            this.requests = response.data[0].requests;
            //this.dtTrigger.next();
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    getCodeTypes() {
        this.loading = true;
        this.service.getCodeTypes('request_status').subscribe(response => {
            this.loading = false;
            this.requestStatus = response.data[0].codeTypes;
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    ngOnInit() {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            ordering: false
        };
        this.getCodeTypes();
        this.getDriverRequests();
    }

}
