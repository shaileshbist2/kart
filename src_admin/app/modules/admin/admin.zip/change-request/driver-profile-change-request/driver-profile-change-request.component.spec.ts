import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverProfileChangeRequestComponent } from './driver-profile-change-request.component';

describe('DriverProfileChangeRequestComponent', () => {
  let component: DriverProfileChangeRequestComponent;
  let fixture: ComponentFixture<DriverProfileChangeRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverProfileChangeRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverProfileChangeRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
