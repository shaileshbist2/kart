import {Component, OnInit} from '@angular/core';
import {ChangeRequestService} from "../change-request.service";

@Component({
    selector: 'app-change-request',
    templateUrl: './change-request.component.html',
    styleUrls: ['./change-request.component.css']
})
export class ChangeRequestComponent implements OnInit {
    loading: boolean = false;
    requestCounts: any = {
        profileRequestCount: 0,
        docRequestCount: 0,
        vehicleRequestCount: 0
    };

    constructor(private service: ChangeRequestService) {
    }

    getChangeRequestCount() {
        this.service.getChangeRequestCount().subscribe(response => {
            this.requestCounts = response.data[0];
        })
    }

    ngOnInit() {
        this.getChangeRequestCount();
    }
}
