import { Component, OnInit } from '@angular/core';
import {Subject} from "rxjs/Subject";
import {ChangeRequestService} from "../change-request.service";
import Swal from 'sweetalert2';
@Component({
  selector: 'app-driver-doc-change-request',
  templateUrl: './driver-doc-change-request.component.html',
  styleUrls: ['./driver-doc-change-request.component.css']
})
export class DriverDocChangeRequestComponent implements OnInit {
    public requests: any = [];
    public loading: boolean = false;
    public dtOptions: DataTables.Settings = {};
    public dtTrigger: Subject<any> = new Subject();
    public display = 'none';
    public requestStatus: any = [];
    public requestType = 1201;
    constructor(private service: ChangeRequestService) {
    }

    getDriverDocChangeRequests() {
        this.loading = true;
        this.service.getDriverDocChangeRequests(this.requestType).subscribe(response => {
            this.loading = false;
            this.requests = response.data[0].requests;
            //this.dtTrigger.next();
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    getCodeTypes() {
        this.loading = true;
        this.service.getCodeTypes('request_status').subscribe(response => {
            this.loading = false;
            this.requestStatus = response.data[0].codeTypes;
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    ngOnInit() {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            ordering: false
        };
        this.getCodeTypes();
        this.getDriverDocChangeRequests();
    }

}
