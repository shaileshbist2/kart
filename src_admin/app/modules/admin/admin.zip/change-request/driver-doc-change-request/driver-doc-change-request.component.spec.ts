import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverDocChangeRequestComponent } from './driver-doc-change-request.component';

describe('DriverDocChangeRequestComponent', () => {
  let component: DriverDocChangeRequestComponent;
  let fixture: ComponentFixture<DriverDocChangeRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverDocChangeRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverDocChangeRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
