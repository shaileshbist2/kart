import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {DriverProfileChangeRequestComponent} from './driver-profile-change-request/driver-profile-change-request.component';
import {ChangeRequestDetailComponent} from './change-request-detail/change-request-detail.component';
import {DriverDocChangeRequestComponent} from './driver-doc-change-request/driver-doc-change-request.component';
import {DriverVehicleChangeRequestComponent} from './driver-vehicle-change-request/driver-vehicle-change-request.component';
import {ChangeRequestComponent} from './change-request/change-request.component';

const routes: Routes = [
    {path: '', component: ChangeRequestComponent},
    {path: 'driver-profile-change-requests', component: DriverProfileChangeRequestComponent},
    {path: 'driver-profile-change-requests/:changeRequestId', component: ChangeRequestDetailComponent},
    {path: 'driver-doc-change-requests', component: DriverDocChangeRequestComponent},
    {path: 'driver-vehicle-change-requests', component: DriverVehicleChangeRequestComponent}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ChangeRequestRoutingModule {
}

export const ChangeRequestRoutingComponents = [
    ChangeRequestComponent, DriverProfileChangeRequestComponent, ChangeRequestDetailComponent,
    DriverDocChangeRequestComponent, DriverVehicleChangeRequestComponent
];
