import {Injectable} from '@angular/core';
import {ApiService} from "../../../shared/api.service";
import {AppConstants} from "../../../shared/app.constants";

@Injectable()
export class ChangeRequestService {

    constructor(private apiService: ApiService) {
    }

    getChangeRequestCount() {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getChangeRequestCount);
    }

    getDriverProfileRequest(typeId) {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getDriverRequests, {typeId: typeId});
    }

    getDriverProfileRequestDetail(driverRequestId) {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getDriverRequestDetail, {driverRequestId: driverRequestId});
    }

    processDriverProfileRequest(driverRequestId, typeId, reason) {
        return this.apiService.executePostMethod(AppConstants.appWriterServiceApi.processDriverRequest, {
            driverRequestId: driverRequestId,
            typeId: typeId,
            reason: reason
        })
    }

    getDriverDocChangeRequests(typeId) {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getDriverDocChangeRequests, {typeId: typeId});
    }

    getCodeTypes(category) {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getCodeTypes, {category: category});
    }
}

