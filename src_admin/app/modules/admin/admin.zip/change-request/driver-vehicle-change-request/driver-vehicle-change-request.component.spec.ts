import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverVehicleChangeRequestComponent } from './driver-vehicle-change-request.component';

describe('DriverVehicleChangeRequestComponent', () => {
  let component: DriverVehicleChangeRequestComponent;
  let fixture: ComponentFixture<DriverVehicleChangeRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DriverVehicleChangeRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverVehicleChangeRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
