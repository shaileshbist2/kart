import {NgModule} from '@angular/core';
import {AdminSharedModule} from '../../../shared/modules/admin-shared.module';
import {ChangeRequestRoutingComponents, ChangeRequestRoutingModule} from './change-request-routing.module';
import {ChangeRequestService} from './change-request.service';

@NgModule({
    imports: [
        AdminSharedModule,
        ChangeRequestRoutingModule
    ],
    declarations: [ChangeRequestRoutingComponents],
    providers: [ChangeRequestService]
})
export class ChangeRequestModule {
}
