import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {ChangeRequestService} from "../change-request.service";
import Swal from 'sweetalert2';

@Component({
    selector: 'app-change-request-detail',
    templateUrl: './change-request-detail.component.html',
    styleUrls: ['./change-request-detail.component.css']
})
export class ChangeRequestDetailComponent implements OnInit {
    public driverRequestId: any;
    public request: any = {
        createDate: "",
        driverRequestId: null,
        newDateOfBirth: "",
        newFirstName: "",
        newLastName: "",
        newMiddleName: "",
        oldDateOfBirth: "",
        oldFirstName: "",
        oldLastName: "",
        oldMiddleName: "",
    };
    public loading: boolean = false;

    constructor(private route: ActivatedRoute,
                private router: Router,
                private service: ChangeRequestService) {
    }

    getDriverRequestDetail() {
        this.loading = true;
        this.service.getDriverProfileRequestDetail(this.driverRequestId).subscribe(response => {
            this.loading = false;
            this.request = response.data[0];
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    approveRequest() {
        this.loading = true;
        this.service.processDriverProfileRequest(this.driverRequestId, 1202, "").subscribe(response => {
            this.loading = false;
            Swal({type: 'success', title: 'Success'}).then(response => {
                this.router.navigateByUrl("/admin/change-requests");
            });
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        });
    }

    rejectRequest() {
        Swal({
            title: 'Reason to reject request',
            input: 'text',
            inputPlaceholder: 'Reason',
            showCancelButton: true,
            inputValidator: (value) => {
                return !value && 'You need to write something!'
            }
        }).then(result => {
            if (result.value) {
                this.loading = true;
                this.service.processDriverProfileRequest(this.driverRequestId, 1203, result.value).subscribe(response => {
                    this.loading = false;
                    Swal({type: 'success', title: 'Success'}).then(response => {
                        this.router.navigateByUrl("/admin/change-requests");
                    });
                }, error => {
                    this.loading = false;
                    Swal({type: 'error', title: error});
                });
            }
        });
    }

    ngOnInit() {
        this.driverRequestId = this.route.snapshot.paramMap.get('changeRequestId');
        this.getDriverRequestDetail();
    }
}
