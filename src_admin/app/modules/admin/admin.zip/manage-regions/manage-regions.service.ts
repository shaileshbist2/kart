import {Injectable} from '@angular/core';
import {ApiService} from "../../../shared/api.service";
import {AppConstants} from "../../../shared/app.constants";

@Injectable()
export class ManageRegionsService {

    constructor(private apiService: ApiService) {
    }

    getCountries() {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getCountries);
    };

    getRegions(appId) {
        let requestParam = {appId: appId};
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getRegions, requestParam);
    };

    addRegion(region) {
        let requestParam = {
            appId: AppConstants.appId,
            regionName: region.regionName,
            countryId: region.countryId,
            coordinates: region.coordinates
        };

        return this.apiService.executePostMethod(AppConstants.appWriterServiceApi.addRegion, requestParam);
    }

    getRegionDetails(regionId) {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getRegionDetail, {regionId: regionId});
    }

    updateRegion(region) {
        return this.apiService.executePostMethod(AppConstants.appWriterServiceApi.updateRegion, region);
    }

    getServices() {
        return this.apiService.executePostMethod(AppConstants.appReaderServiceApi.getServices, {appId: AppConstants.appId});
    }

    updateRegionFlags(regionDetail) {
        return this.apiService.executePostMethod(AppConstants.appWriterServiceApi.updateRegionFlags, regionDetail);
    }

    saveRegionService(regionService) {
        return this.apiService.executePostMethod(AppConstants.appWriterServiceApi.saveRegionService, regionService);
    }

}
