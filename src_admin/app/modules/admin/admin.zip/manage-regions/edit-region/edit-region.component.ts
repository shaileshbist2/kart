import {Component, ElementRef, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import Swal from 'sweetalert2';
import {ManageRegionsService} from "../manage-regions.service";

declare var google: any;

@Component({
    selector: 'app-edit-region',
    templateUrl: './edit-region.component.html',
    styleUrls: ['./edit-region.component.css']
})

export class EditRegionComponent implements OnInit {

    public map: google.maps.Map;
    public drawingManager: google.maps.drawing.DrawingManager;
    public coordinates: any = [];
    public polygonArray: any = [];
    public selectedShape: any;
    public all_overlays: any = [];
    public regionId: any;
    public regionDetail = {
        regionId: 0,
        countryId: null,
        regionName: "",
        coordinates: []
    };
    public countries = [];
    public loading = false;

    constructor(private element: ElementRef,
                private service: ManageRegionsService,
                private router: Router,
                private route: ActivatedRoute) {

    }

    getRegionDetail() {
        this.loading = true;
        this.service.getRegionDetails(this.regionId).subscribe(response => {
            this.loading = false;
            this.regionDetail = response.data[0];
            let bounds = new google.maps.LatLngBounds();
            for (let i = 0; i < this.regionDetail.coordinates.length; i++) {
                let position = new google.maps.LatLng(this.regionDetail.coordinates[i][0], this.regionDetail.coordinates[i][1]);
                this.coordinates.push(position);
                bounds.extend(position);
            }
            this.map.setCenter(this.coordinates[0]);
            let polygon = new google.maps.Polygon({
                paths: this.coordinates,
                fillColor: '#BCDCF9',
                fillOpacity: 0.5,
                strokeWeight: 2,
                strokeColor: '#57ACF9',
                clickable: true,
                editable: false,
                zIndex: 1
            });
            polygon.setMap(this.map);
            this.map.fitBounds(bounds);
            this.setSelection(polygon);
            this.drawingManager.setDrawingMode(null);
        }, error => {
            this.loading = false;
        })
    }

    initialize() {
        this.map = new google.maps.Map(this.element.nativeElement.querySelector("#map_canvas"), {
            center: new google.maps.LatLng(37.4419, -122.1419),
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true,
            zoomControl: true
        });

        this.drawingManager = new google.maps.drawing.DrawingManager({
            drawingMode: google.maps.drawing.OverlayType.POLYGON,
            drawingControl: false,
            markerOptions: {
                position: this.map.getCenter(),
                draggable: true
            },
            polygonOptions: {
                fillColor: '#BCDCF9',
                fillOpacity: 0.5,
                strokeWeight: 2,
                strokeColor: '#57ACF9',
                clickable: true,
                editable: false,
                zIndex: 1
            },
            map: this.map
        });

        google.maps.event.addListener(this.drawingManager, 'polygoncomplete', (polygon) => {
            this.polygonArray = [];
            for (let i = 0; i < polygon.getPath().getLength(); i++) {
                this.polygonArray[i] = (polygon.getPath().getAt(i).toUrlValue(6));
            }
            this.polygonArray.push(this.polygonArray[0]);
            this.regionDetail.coordinates = this.polygonArray;
            this.drawingManager.setDrawingMode(null);
        });

        google.maps.event.addListener(this.drawingManager, 'overlaycomplete', (e) => {
            this.addOverlay(e);
            if (e.type != google.maps.drawing.OverlayType.MARKER) {
                // Switch back to non-drawing mode after drawing a shape.
                this.drawingManager.setDrawingMode(null);
                // Add an event listener that selects the newly-drawn shape when the user
                // mouses down on it.
                let newShape = e.overlay;
                newShape.type = e.type;
                google.maps.event.addListener(newShape, 'click', () => {
                    this.setSelection(newShape);
                });
                this.setSelection(newShape);
            }
        });
    }

    addOverlay(overlay) {
        this.all_overlays[this.all_overlays.length] = overlay;
    }

    clearPolygon() {
        if (this.selectedShape) {
            this.selectedShape.setMap(null);
            this.drawingManager.setMap(null);
            this.polygonArray = [];
            this.regionDetail.coordinates = [];
        }
        this.drawingManager.setMap(this.map);
        this.drawingManager.setDrawingMode(google.maps.drawing.OverlayType.POLYGON);
        this.refreshMap();
    }

    refreshMap() {
        google.maps.event.trigger(this.map, 'resize');
    }

    clearSelection() {
        if (this.selectedShape) {
            this.selectedShape = null;
        }
    }

    setSelection(shape) {
        this.clearSelection();
        this.selectedShape = shape;
        //shape.setEditable(true);
    }

    saveRegion() {
        this.loading = true;
        this.service.updateRegion(this.regionDetail).subscribe(response => {
            this.loading = false;
            if (response.status) {
                this.router.navigateByUrl('admin/manage-regions');
            } else {
                Swal({type: 'error', title: response.msg});
            }
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        });
    }

    getCountries() {
        this.service.getCountries().subscribe(response => {
            this.countries = response.data[0].countries;
        });
    }

    ngOnInit() {
        this.regionId = this.route.snapshot.paramMap.get('regionId');
        this.getCountries();
        this.getRegionDetail();
        this.initialize();
        this.refreshMap();
    }

}
