import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManageRegionsRoutingModule } from './manage-regions-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ManageRegionsRoutingModule
  ],
  declarations: []
})
export class ManageRegionsModule { }
