import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import Swal from 'sweetalert2';
import {ManageRegionsService} from "../manage-regions.service";

declare var $: any;

@Component({
    selector: 'app-region-settings',
    templateUrl: './region-settings.component.html',
    styleUrls: ['./region-settings.component.css']
})
export class RegionSettingsComponent implements OnInit {
    public regionDetail: any = {
        fcmFlag: 0,
        msgFlag: 0,
        activeFlag: 0,
        services: []
    };
    public regionService: any;
    public services: any;
    public regionId: any;
    public loading: boolean = false;

    constructor(private service: ManageRegionsService,
                private route: ActivatedRoute) {
    }

    getRegionServiceEmptyObject() {
        return {
            regionServiceXrefId: 0,
            regionId: this.regionId,
            serviceId: null,
            baseFare: 0,
            minimumFare: 0,
            perMileFare: 0,
            timeFare: 0,
            waitingTimeFare: 0,
            tax: 0,
            tipToDriver: "",
            tripCancellationFee: 0,
            bookingFee: 0,
            serviceCharge: 0,
            cashFlag: true
        };
    }

    getRegionDetail() {
        this.loading = true;
        this.service.getRegionDetails(this.regionId).subscribe(response => {
            this.loading = false;
            this.regionDetail = response.data[0];
            this.regionDetail.fcmFlag = this.regionDetail.fcmFlag == 1;
            this.regionDetail.msgFlag = this.regionDetail.msgFlag == 1;
            this.regionDetail.activeFlag = this.regionDetail.activeFlag == 1;
            console.log(this.regionDetail);
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    getServices() {
        this.service.getServices().subscribe(response => {
            this.services = response.data[0].services;
        }, error => {
            Swal({type: 'error', title: error});
        })
    }

    updateRegionFlags() {
        this.regionDetail.fcmFlag = this.regionDetail.fcmFlag == true ? 1 : 0;
        this.regionDetail.msgFlag = this.regionDetail.msgFlag == true ? 1 : 0;
        this.regionDetail.activeFlag = this.regionDetail.activeFlag == true ? 1 : 0;
        this.loading = true;
        this.service.updateRegionFlags(this.regionDetail).subscribe(response => {
            this.loading = false;
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        });
    }

    saveRegionService() {
        this.regionService.cashFlag = this.regionService.cashFlag == true ? 1 : 0;
        this.loading = true;
        this.service.saveRegionService(this.regionService).subscribe(response => {
            this.loading = false;
            $('#myModal').modal('hide');
            this.getRegionDetail();
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        })
    }

    showPopup() {
        this.regionService = this.getRegionServiceEmptyObject();
        $('#myModal').modal('show');
    }

    editRegionService(regionService) {
        console.log(this.regionService);
        this.regionService = regionService;
        $('#myModal').modal('show');
    }

    ngOnInit() {
        this.regionService = this.getRegionServiceEmptyObject();
        this.regionId = this.route.snapshot.paramMap.get('regionId');
        this.getServices();
        this.getRegionDetail();
    }

}
