import {Component, OnInit} from '@angular/core';
import {AppConstants} from "../../../../shared/app.constants";
import {Router} from "@angular/router";
import Swal from 'sweetalert2';
import {ManageRegionsService} from "../manage-regions.service";

@Component({
    selector: 'app-list-regions',
    templateUrl: './list-regions.component.html',
    styleUrls: ['./list-regions.component.css']
})
export class ListRegionsComponent implements OnInit {
    public loading: boolean = false;
    public regions: any;

    constructor(private listRegionService: ManageRegionsService,
                private router: Router) {
    }

    ngOnInit() {
        this.getRegions();
    }

    getRegions() {
        this.loading = true;
        this.listRegionService.getRegions(AppConstants.appId).subscribe(response => {
            this.loading = false;
            this.regions = response.data[0].regions;
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        });
    };
}
