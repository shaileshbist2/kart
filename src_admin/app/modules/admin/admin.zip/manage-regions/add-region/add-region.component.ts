import {Component, ElementRef, OnInit} from '@angular/core';
import {} from '@types/googlemaps';
import {Router} from "@angular/router";
import Swal from 'sweetalert2';
import {ManageRegionsService} from "../manage-regions.service";

@Component({
    selector: 'app-add-region',
    templateUrl: './add-region.component.html',
    styleUrls: ['./add-region.component.css']
})
export class AddRegionComponent implements OnInit {
    public map: google.maps.Map;
    public drawingManager: google.maps.drawing.DrawingManager;
    public polygonArray: any = [];
    public selectedShape: any;
    public all_overlays: any = [];
    public newRegion = {
        regionId: 0,
        countryId: null,
        regionName: "",
        coordinates: []
    };
    public countries = [];
    public loading = false;

    constructor(private element: ElementRef,
                private service: ManageRegionsService,
                private router: Router) {

    }

    initialize() {
        this.map = new google.maps.Map(this.element.nativeElement.querySelector("#map_canvas"), {
            center: new google.maps.LatLng(37.4419, -122.1419),
            zoom: 13,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true,
            zoomControl: true
        });

        this.drawingManager = new google.maps.drawing.DrawingManager({
            drawingMode: google.maps.drawing.OverlayType.POLYGON,
            drawingControl: false,
            markerOptions: {
                position: this.map.getCenter(),
                draggable: true
            },
            polygonOptions: {
                fillColor: '#BCDCF9',
                fillOpacity: 0.5,
                strokeWeight: 2,
                strokeColor: '#57ACF9',
                clickable: true,
                editable: false,
                zIndex: 1
            },
            map: this.map
        });

        google.maps.event.addListener(this.drawingManager, 'polygoncomplete', (polygon) => {
            this.polygonArray = [];
            for (let i = 0; i < polygon.getPath().getLength(); i++) {
                this.polygonArray[i] = (polygon.getPath().getAt(i).toUrlValue(6));
            }
            this.polygonArray.push(this.polygonArray[0]);
            this.newRegion.coordinates = this.polygonArray;
            this.drawingManager.setDrawingMode(null);
        });

        google.maps.event.addListener(this.drawingManager, 'overlaycomplete', (e) => {
            this.addOverlay(e);
            if (e.type != google.maps.drawing.OverlayType.MARKER) {
                // Switch back to non-drawing mode after drawing a shape.
                this.drawingManager.setDrawingMode(null);
                // Add an event listener that selects the newly-drawn shape when the user
                // mouses down on it.
                let newShape = e.overlay;
                newShape.type = e.type;
                google.maps.event.addListener(newShape, 'click', () => {
                    this.setSelection(newShape);
                });
                this.setSelection(newShape);
            }
        });
    }

    addOverlay(overlay) {
        this.all_overlays[this.all_overlays.length] = overlay;
    }

    clearPolygon() {
        if (this.selectedShape) {
            this.selectedShape.setMap(null);
            document.getElementById('info').innerHTML = "";
            this.drawingManager.setMap(null);
            this.polygonArray = [];
            this.newRegion.coordinates = [];
        }
        this.drawingManager.setMap(this.map);
        this.drawingManager.setDrawingMode(google.maps.drawing.OverlayType.POLYGON);
        this.refreshMap();
    }

    refreshMap() {
        console.log('map refreshed');
        google.maps.event.trigger(this.map, 'resize');
    }

    clearSelection() {
        if (this.selectedShape) {
            this.selectedShape = null;
        }
    }


    setSelection(shape) {
        this.clearSelection();
        this.selectedShape = shape;
    }

    saveRegion() {
        this.loading = true;
        this.service.addRegion(this.newRegion).subscribe(response => {
            this.loading = false;
            if (response.status) {
                this.router.navigateByUrl('admin/manage-regions');
            } else {
                Swal({type: 'error', title: response.msg});
            }
        }, error => {
            this.loading = false;
            Swal({type: 'error', title: error});
        });
    }

    getCountries() {
        this.service.getCountries().subscribe(response => {
            this.countries = response.data[0].countries;
        });
    }

    ngOnInit() {
        this.getCountries();
        this.initialize();
        this.refreshMap();
    }
}