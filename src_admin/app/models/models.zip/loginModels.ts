export class LoginModel {
  public emailId: string = null;
  public password: string = null;
}

export class AdminLoginModel {
  public email_id: string = null;
  public password: string = null;
}
