export class PassengerSignupStepOneModel {
    firstName: string = '';
    middleName: string = '';
    lastName: string = '';
    email: string = '';
    diallingCode: string = '44';
    mobile: string = '';
    password: string = '';
    cPassword: string = '';
    referralCode: string = '';
    acceptedAgreement: boolean;
    deviceInfo: any;
}

export class PassengerSignupStepTwoModel {
    verificationCode: string = '';
}