export class EditDriverBasicProfile {
    firstName: string = null;
    lastName: string = null;
    password: string = null;
    cPassword: string = null;
    profilePic: File = null;
    driverId: Number = null;
}