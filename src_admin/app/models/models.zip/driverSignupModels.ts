export class DriverSignupStepOneModel {
    regionId: number = null;
    firstName: string = '';
    middleName: string = '';
    lastName: string = '';
    email: string = '';
    mobile: string = '';
    password: string = '';
    cPassword: string = '';
    referralCode: string = '';
    acceptedAgreement: boolean;
    deviceInfo: any;
}

export class DriverSignupStepTwoModel {
    verificationCode: string = '';
}

export class DriverSignupStepThreeModel {
    profilePic: File = null;
}

export class DriverSignupStepFourModel {
    DLImage: File = null;
    DLNumber: string = '';
    DLExpiryDay: string = '';
    DLExpiryMonth: string = '';
    DLExpiryYear: string = '';
}

export class DriverSignupStepFiveModel {
    carFrontView: File = null;
    carSideView: File = null;
    carBackView: File = null;
    carMake: string = null;
    carModel: string = null;
    registrationNumber: string = null;
    carColor: string = null;
    services: number[] = []
}

export class DriverSignupStepSixModel {
    regImage: File = null;
    regNumber: string = '';
    regExpiryDay: string = '';
    regExpiryMonth: string = '';
    regExpiryYear: string = '';
}

export class DriverSignupStepSevenModel {
    insuranceImage: File = null;
    insuranceNumber: string = '';
    insuranceExpiryDay: string = '';
    insuranceExpiryMonth: string = '';
    insuranceExpiryYear: string = '';
}

export class DriverSignupStepEightModel {
    accreditationImage: File = null;
    accreditationNumber: string = '';
    accreditationExpiryDay: string = '';
    accreditationExpiryMonth: string = '';
    accreditationExpiryYear: string = '';
}

export class DriverSignupStepNineModel {
    nationalInsuranceImage: File = null;
    nationalInsuranceNumber: string = '';
    nationalInsuranceExpiryDay: string = '';
    nationalInsuranceExpiryMonth: string = '';
    nationalInsuranceExpiryYear: string = '';
}