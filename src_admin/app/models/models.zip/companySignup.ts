export class CompanySignupStepOneModel {
    regionId: number = null;
    companyName: string = null;
    firstName: string = null;
    lastName: string = null;
    email: string = null;
    mobile: string = null;
    password: string = null;
    cPassword: string = null;
    referralCode: string = null;
    acceptedAgreement: boolean;
    deviceInfo: any;
}

export class CompanySignupStepTwoModel {
    verificationCode: number = null;
}